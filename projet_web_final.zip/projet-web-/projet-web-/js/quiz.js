const questions = [
    {
        question: "Qui a inventé l’avion en 1903 ?",
        answers: [
            { text: "Les frères Wright", correct: true },
            { text: "Albert Einstein", correct: false },
            { text: "Nikola Tesla", correct: false },
        ]
    },
    {
        question: "Quelle invention a permis le développement des ordinateurs ?",
        answers: [
            { text: "L’ampoule", correct: false },
            { text: "Le transistor", correct: true },
            { text: "La radio", correct: false },
        ]
    },
    {
        question: "Quelle année marque la naissance du Bitcoin ?",
        answers: [
            { text: "2009", correct: true },
            { text: "2012", correct: false },
            { text: "1998", correct: false },
        ]
    },
    {
        question: "Qui a découvert la pénicilline en 1928 ?",
        answers: [
            { text: "Alexander Fleming", correct: true },
            { text: "Marie Curie", correct: false },
            { text: "Isaac Newton", correct: false },
        ]
    },
    {
        question: "Qu’est-ce que l’IA (intelligence artificielle) ?",
        answers: [
            { text: "Un type de moteur", correct: false },
            { text: "Une invention médicale", correct: false },
            { text: "Une machine capable d’imiter l’intelligence humaine", correct: true },
        ]
    },
    {
        question: "Quel réseau social a été lancé en 2004 ?",
        answers: [
            { text: "Instagram", correct: false },
            { text: "TikTok", correct: false },
            { text: "Facebook", correct: true },
        ]
    },
    {
        question: "Quel pays a lancé Internet à l’origine (ARPANET) ?",
        answers: [
            { text: "France", correct: false },
            { text: "États-Unis", correct: true },
            { text: "Allemagne", correct: false },
        ]
    },
    {
        question: "Quelle entreprise est pionnière dans la voiture autonome ?",
        answers: [
            { text: "Tesla", correct: true },
            { text: "Peugeot", correct: false },
            { text: "Renault", correct: false },
        ]
    },
    {
        question: "Quelle technologie est liée à la cryptomonnaie ?",
        answers: [
            { text: "Blockchain", correct: true },
            { text: "Fibre optique", correct: false },
            { text: "Bluetooth", correct: false },
        ]
    },
    {
        question: "Quel inventeur est connu pour ses travaux sur le courant alternatif ?",
        answers: [
            { text: "Thomas Edison", correct: false },
            { text: "Nikola Tesla", correct: true },
            { text: "James Watt", correct: false },
        ]
    }
];

const startBtn = document.getElementById("start-btn");
const nextBtn = document.getElementById("next-btn");
const questionContainer = document.getElementById("question-container");
const questionElement = document.getElementById("question");
const answersElement = document.getElementById("answers");
const resultContainer = document.getElementById("result-container");
const scoreText = document.getElementById("score-text");

let currentQuestionIndex = 0;
let score = 0;

startBtn.addEventListener("click", startQuiz);
nextBtn.addEventListener("click", () => {
    currentQuestionIndex++;
    setNextQuestion();
});

function startQuiz() {
    document.getElementById("start-container").classList.add("hidden");
    questionContainer.classList.remove("hidden");
    currentQuestionIndex = 0;
    score = 0;
    setNextQuestion();
}

function setNextQuestion() {
    resetState();
    if (currentQuestionIndex < questions.length) {
        showQuestion(questions[currentQuestionIndex]);
    } else {
        showResult();
    }
}

function showQuestion(questionObj) {
    questionElement.innerText = questionObj.question;
    questionObj.answers.forEach(answer => {
        const button = document.createElement("button");
        button.innerText = answer.text;
        button.classList.add("btn");
        if (answer.correct) {
            button.dataset.correct = true;
        }
        button.addEventListener("click", selectAnswer);
        answersElement.appendChild(button);
    });
}

function resetState() {
    nextBtn.classList.add("hidden");
    answersElement.innerHTML = "";
}

function selectAnswer(e) {
    const selectedBtn = e.target;
    const correct = selectedBtn.dataset.correct === "true";

    if (correct) score++;

    Array.from(answersElement.children).forEach(button => {
        setStatusClass(button, button.dataset.correct === "true");
        button.disabled = true;
    });

    nextBtn.classList.remove("hidden");
}

function setStatusClass(element, correct) {
    if (correct) {
        element.classList.add("correct");
    } else {
        element.classList.add("wrong");
    }
}

function showResult() {
    questionContainer.classList.add("hidden");
    resultContainer.classList.remove("hidden");

    let feedback;
    const percent = (score / questions.length) * 100;

    if (percent === 100) feedback = "Parfait ! Vous êtes un(e) génie des inventions.";
    else if (percent >= 80) feedback = "Excellent travail ! Vous maîtrisez bien le sujet.";
    else if (percent >= 50) feedback = "Pas mal ! Encore un petit effort.";
    else feedback = "C’est le moment de découvrir ces inventions sur notre site !";

    scoreText.innerText = `Votre score : ${score} / ${questions.length} \n\n${feedback}`;
}
