// JS interactivité - antibiotiques.js

// Frise historique interactive
function showInfo(year) {
  const info = {
    1928: "1928 - Découverte de la pénicilline par Alexander Fleming.",
    1940: "1940 - Production à grande échelle pour soigner les soldats pendant la guerre.",
    1950: "1950 - Apparition de nouvelles familles d’antibiotiques (tétracyclines, macrolides, etc.).",
    1980: "1980 - Mise en garde contre la surconsommation d’antibiotiques et les premières résistances bactériennes.",
    2020: "2020 - L’OMS déclare la résistance aux antibiotiques comme une urgence sanitaire mondiale."
  };

  document.getElementById("timeline-info").textContent = info[year] || "Aucune donnée pour cette année.";
}

// Mini quiz
function checkAnswer(button) {
  const feedback = document.getElementById("quiz-feedback");
  if (button.dataset.correct === "true") {
    feedback.textContent = "✅ Bonne réponse ! Alexander Fleming a découvert la pénicilline en 1928.";
    feedback.style.color = "green";
  } else {
    feedback.textContent = "❌ Mauvaise réponse. Essaie encore !";
    feedback.style.color = "red";
  }
}
// Frise chronologique
function showInfo(year) {
  const info = {
    1928: "Alexander Fleming découvre la pénicilline, premier antibiotique.",
    1941: "Première utilisation clinique de la pénicilline aux États-Unis.",
    1952: "Découverte de la streptomycine pour traiter la tuberculose.",
    1980: "Multiplication des antibiotiques de synthèse.",
    2020: "Montée des résistances bactériennes : un défi mondial majeur."
  };

  document.getElementById("timeline-info").textContent = info[year] || "Aucune information disponible.";
}

// Mini quiz
function checkAnswer(button) {
  const feedback = document.getElementById("quiz-feedback");

  if (button.dataset.correct === "true") {
    button.classList.add("correct");
    feedback.textContent = "✅ Bonne réponse ! C'est bien Alexander Fleming.";
  } else {
    button.classList.add("wrong");
    feedback.textContent = "❌ Mauvaise réponse. Essaie encore.";
  }

  const buttons = button.parentElement.querySelectorAll("button");
  buttons.forEach(btn => btn.disabled = true);
}
