// Gère l'affichage des événements de la frise chronologique
function showInfo(year) {
  const info = {
    1956: "Naissance officielle de l'intelligence artificielle lors de la conférence de Dartmouth. Le terme 'IA' est proposé pour la première fois.",
    1997: "L'ordinateur Deep Blue d'IBM bat le champion du monde d’échecs Garry Kasparov, marquant un tournant dans la perception de l'IA.",
    2012: "Une percée dans l’apprentissage profond (deep learning) permet à une IA de Google de reconnaître des chats dans des vidéos YouTube sans étiquettes.",
    2016: "AlphaGo, développé par DeepMind, bat un champion mondial du jeu de Go, démontrant la puissance des réseaux neuronaux profonds.",
    2023: "L'IA générative (comme ChatGPT ou DALL·E) devient grand public, changeant la manière dont nous créons, travaillons et communiquons."
  };

  const infoElement = document.getElementById("timeline-info");
  infoElement.textContent = info[year] || "Aucune information disponible pour cette année.";
}

// Gère le mini quiz interactif
function checkAnswer(button) {
  const feedback = document.getElementById("quiz-feedback");
  const isCorrect = button.dataset.correct === "true";

  // Réinitialise tous les boutons
  const buttons = button.parentElement.querySelectorAll("button");
  buttons.forEach(btn => {
    btn.classList.remove("correct", "wrong");
    btn.disabled = true; // Empêche de recliquer
  });

  if (isCorrect) {
    button.classList.add("correct");
    feedback.textContent = "Bonne réponse ! 🎉";
  } else {
    button.classList.add("wrong");
    feedback.textContent = "Oops, mauvaise réponse. Réessaie la prochaine fois !";
  }
}
