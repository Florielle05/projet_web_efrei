// === Gestion de la frise chronologique ===
function showInfo(year) {
  const info = {
    2003: "Lancement de MySpace, l’un des premiers réseaux sociaux populaires.",
    2004: "Mark Zuckerberg crée Facebook à l’université de Harvard.",
    2010: "Instagram est lancé, mettant l’accent sur le partage de photos.",
    2016: "TikTok commence à gagner en popularité dans le monde entier.",
    2020: "Explosion des contenus vidéo courts avec TikTok et Reels sur Instagram."
  };

  const text = info[year] || "Aucune information disponible pour cette année.";
  document.getElementById("timeline-info").textContent = text;
}

// === Gestion du mini quiz ===
function checkAnswer(button) {
  const feedback = document.getElementById("quiz-feedback");

  if (button.dataset.correct === "true") {
    button.classList.add("correct");
    feedback.textContent = "✅ Bravo ! Facebook a été fondé en 2004 par Mark Zuckerberg.";
  } else {
    button.classList.add("wrong");
    feedback.textContent = "❌ Ce n’est pas la bonne réponse. Réfléchis à qui a créé Facebook.";
  }

  const buttons = button.parentElement.querySelectorAll("button");
  buttons.forEach(btn => btn.disabled = true);
}
