// JS interactivité - avion.js

// Frise historique interactive
function showInfo(year) {
  const info = {
    1903: "1903 - Premier vol motorisé par les frères Wright à Kitty Hawk, USA.",
    1914: "1914 - Premier vol commercial régulier entre St Petersburg et Tampa (Floride).",
    1939: "1939 - Premier vol d’un avion à réaction en Allemagne.",
    1969: "1969 - Premier vol du Concorde, avion supersonique franco-britannique.",
    2005: "2005 - Premier vol de l’Airbus A380, plus grand avion de ligne du monde."
  };

  document.getElementById("timeline-info").textContent = info[year] || "Aucune donnée pour cette année.";
}

// Mini quiz
function checkAnswer(button) {
  const feedback = document.getElementById("quiz-feedback");
  if (button.dataset.correct === "true") {
    feedback.textContent = "✅ Bonne réponse ! Les frères Wright sont les pionniers de l’aviation.";
    feedback.style.color = "green";
  } else {
    feedback.textContent = "❌ Mauvaise réponse. Essaie encore !";
    feedback.style.color = "red";
  }
}
