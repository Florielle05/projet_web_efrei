// === Gestion de la frise chronologique ===
function showInfo(year) {
  const info = {
    1969: "ARPANET établit sa première connexion entre deux ordinateurs : c’est la naissance d’Internet.",
    1989: "Tim Berners-Lee propose le World Wide Web, un système de navigation hypertexte accessible via Internet.",
    1993: "Lancement de Mosaic, le premier navigateur web graphique, qui démocratise l’Internet.",
    2007: "L’iPhone popularise l’accès mobile à Internet dans le monde entier.",
    2020: "Explosion de l’usage d’Internet durant la pandémie pour le télétravail, les cours à distance, et les vidéoconférences."
  };

  const text = info[year] || "Aucune information disponible pour cette année.";
  document.getElementById("timeline-info").textContent = text;
}

// === Gestion du mini quiz ===
function checkAnswer(button) {
  const feedback = document.getElementById("quiz-feedback");

  if (button.dataset.correct === "true") {
    button.classList.add("correct");
    feedback.textContent = "✅ Bonne réponse ! ARPANET est bien l’ancêtre d’Internet.";
  } else {
    button.classList.add("wrong");
    feedback.textContent = "❌ Mauvaise réponse. Essaie encore : quel projet militaire a tout lancé ?";
  }

  // Désactiver tous les boutons après la réponse
  const buttons = button.parentElement.querySelectorAll("button");
  buttons.forEach(btn => btn.disabled = true);
}
