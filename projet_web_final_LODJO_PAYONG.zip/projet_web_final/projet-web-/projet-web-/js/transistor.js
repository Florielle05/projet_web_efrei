// JS interactivité - transistor.js

// Frise historique interactive
function showInfo(year) {
  const info = {
    1947: "1947 - Invention du transistor aux Bell Labs par John Bardeen, Walter Brattain et William Shockley.",
    1956: "1956 - Prix Nobel de Physique attribué aux trois inventeurs du transistor.",
    1971: "1971 - Premier microprocesseur Intel 4004, utilisant des transistors pour l'ère numérique.",
    2000: "2000 - Des millions de transistors intégrés dans les puces électroniques modernes.",
    2020: "2020 - Des milliards de transistors dans les smartphones et les ordinateurs actuels."
  };

  const infoElement = document.getElementById("timeline-info");
  infoElement.textContent = info[year] || "Aucune donnée pour cette année.";
}

// Mini quiz
function checkAnswer(button) {
  const feedback = document.getElementById("quiz-feedback");
  if (button.dataset.correct === "true") {
    feedback.textContent = "✅ Bonne réponse ! Le transistor est l'invention clé de l'électronique moderne.";
    feedback.style.color = "green";
  } else {
    feedback.textContent = "❌ Mauvaise réponse. Essaie encore !";
    feedback.style.color = "red";
  }
}
