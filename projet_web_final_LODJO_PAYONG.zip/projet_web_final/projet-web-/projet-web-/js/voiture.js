// === Gestion de la frise chronologique ===
function showInfo(year) {
  const info = {
    2004: "Première compétition DARPA Grand Challenge : les voitures autonomes doivent parcourir 240 km dans le désert. Aucun véhicule ne termine la course.",
    2010: "Google annonce travailler secrètement sur des voitures autonomes. Le projet deviendra plus tard Waymo.",
    2015: "Tesla introduit l’Autopilot sur ses véhicules, une étape majeure vers l’autonomie.",
    2021: "Waymo et Cruise testent des taxis autonomes sans conducteur dans certaines villes.",
    2024: "Plusieurs villes autorisent la circulation de véhicules entièrement autonomes dans certaines zones."
  };

  const text = info[year] || "Aucune information disponible pour cette année.";
  document.getElementById("timeline-info").textContent = text;
}

// === Gestion du mini quiz ===
function checkAnswer(button) {
  const feedback = document.getElementById("quiz-feedback");

  if (button.dataset.correct === "true") {
    button.classList.add("correct");
    feedback.textContent = "✅ Bravo ! Le LIDAR est essentiel pour cartographier l’environnement en 3D.";
  } else {
    button.classList.add("wrong");
    feedback.textContent = "❌ Ce n’est pas la bonne réponse. Pense à un outil qui 'voit' en 3D.";
  }

  const buttons = button.parentElement.querySelectorAll("button");
  buttons.forEach(btn => btn.disabled = true);
}
