// === Gestion de la frise chronologique ===
function showInfo(year) {
  const info = {
    2008: "Publication du whitepaper du Bitcoin par Satoshi Nakamoto : une nouvelle monnaie numérique sans tiers de confiance.",
    2009: "Lancement officiel du Bitcoin. Le premier bloc de la blockchain, appelé le « bloc Genesis », est miné.",
    2015: "Apparition d'Ethereum, une plateforme blockchain permettant de créer des contrats intelligents (smart contracts).",
    2021: "Explosion des NFT (jetons non fongibles) et adoption massive des cryptos par des entreprises comme Tesla ou PayPal.",
    2024: "Les banques centrales accélèrent le développement de leurs propres monnaies numériques (CBDC)."
  };

  const text = info[year] || "Aucune information disponible pour cette année.";
  document.getElementById("timeline-info").textContent = text;
}

// === Gestion du mini quiz ===
function checkAnswer(button) {
  const feedback = document.getElementById("quiz-feedback");

  if (button.dataset.correct === "true") {
    button.classList.add("correct");
    feedback.textContent = "✅ Bonne réponse ! La blockchain est bien la base des cryptomonnaies.";
  } else {
    button.classList.add("wrong");
    feedback.textContent = "❌ Mauvaise réponse. Réfléchis bien à ce qui garantit la sécurité et la transparence des cryptos.";
  }

  // Désactiver tous les boutons après la réponse
  const buttons = button.parentElement.querySelectorAll("button");
  buttons.forEach(btn => btn.disabled = true);
}
