document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("contact-form");
  const feedback = document.getElementById("form-feedback");

  form.addEventListener("submit", function (event) {
    event.preventDefault(); // Empêche l'envoi réel

    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const message = form.message.value.trim();

    if (name && email && message) {
      feedback.textContent = `Merci ${name}, votre message a bien été envoyé !`;
      feedback.style.color = "green";
      form.reset();
    } else {
      feedback.textContent = "Merci de remplir tous les champs.";
      feedback.style.color = "red";
    }
  });
});
